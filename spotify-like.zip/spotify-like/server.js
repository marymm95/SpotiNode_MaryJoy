const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
require('dotenv').config();

const app = express();
const port = 3000;

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static('uploads'));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});


const fileFilter = (req, file, cb) => {
    const allowedTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3'];
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Invalid file type. Only audio files are allowed!'), false);
    }
};

const upload = multer({ storage: storage, fileFilter: fileFilter });

const db = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'spotify_db'
});

db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// Add new song
app.post('/add-song', upload.single('file'), (req, res) => {
    const { title, artist, album, genre } = req.body;
    const url = `http://localhost:${port}/uploads/${req.file.filename}`;

    const query = 'INSERT INTO songs(title, artist, album, genre, url) VALUES(?,?,?,?,?)';
    db.query(query, [title, artist, album, genre, url], (err, result) => {
        if (err) {
            console.error('Error adding song:', err);
            return res.status(500).send({ message: 'Error adding song' });
        }
        res.status(201).send({ message: 'Song added successfully!' });
    });
});

app.get('/songs', (req, res) => {
    const query = 'SELECT * FROM songs';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching songs:', err);
            return res.status(500).send({ message: 'Error fetching songs' });
        }
        res.json(results);
    });
});

app.get('/search-songs', (req, res) => {
    const { query } = req.query; 
    const sqlQuery = `
        SELECT * FROM songs
        WHERE title LIKE ? OR artist LIKE ? OR album LIKE ?
    `;
    const searchQuery = `%${query}%`; 
    db.query(sqlQuery, [searchQuery, searchQuery, searchQuery], (err, results) => {
        if (err) {
            console.error('Error searching songs:', err);
            return res.status(500).send({ message: 'Error searching songs' });
        }
        res.json(results);
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
